//
//  AboutViewController.swift
//  BullsEye
//
//  Created by Bane Manojlovic on 14/07/2020.
//  Copyright © 2020 Bane Manojlovic. All rights reserved.
//

import UIKit
import WebKit

class AboutViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var webView: WKWebView!
    

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let url = Bundle.main.url(forResource: "BullsEye",
                                     withExtension: "html") {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    // MARK: - Action Methods
    @IBAction func closeScreen(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

}
